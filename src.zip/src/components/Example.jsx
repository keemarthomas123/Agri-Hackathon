import React from 'react';

const Example = () => {
    return (
        <div>
            <h1>This is an Example Component</h1>
            <p>Welcome to the Example component!</p>
        </div>
    );
};

export default Example;